
User Relationship Elaborations
------------------------------
Gives users the opportunity to elaborate on their relationship to another user.

There's a setting on the User Relationships administration page that lets admins
choose to only use the API portions of this module. If checked it will hide all
UI elements of the interface.
